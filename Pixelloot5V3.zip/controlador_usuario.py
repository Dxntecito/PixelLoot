from bd import conectar

def insertar_usuario(nombre_usuario,nombre_real, correo, genero, contraseña,
                     telefono, pais, fecha_nacimiento, rolid_rol,
                     foto_perfil, foto_portada):
    conexion = conectar()
    with conexion.cursor() as cursor:
        cursor.execute(
            "INSERT INTO usuario (nombre_usuario,nombre_real, correo, genero, contraseña, telefono, pais, fecha_nacimiento, rolid_rol, foto_perfil, foto_portada) "
            "VALUES (%s, %s,%s, %s, %s, %s, %s, %s, %s, %s, %s)",
            (nombre_usuario, nombre_real, correo, genero, contraseña, telefono, pais, fecha_nacimiento, rolid_rol, foto_perfil, foto_portada)
        )
    conexion.commit()
    conexion.close()