from flask import Flask, render_template, request
from controlador_juego import obtener_juegos
from controlador_juego import agregar_juego
from controlador_juego import obtener_juego_por_id
from controlador_juego import obtener_similares
from controlador_usuario import insertar_usuario

app = Flask(__name__)

# Página principal
@app.route("/")
def index():
    return render_template("index.html")

# Rutas del menú principal
@app.route('/tienda')
def tienda():
    juegos = obtener_juegos()
    return render_template('tienda.html', juegos=juegos)

@app.route("/sobre-nosotros")
def sobre_nosotros():
    return render_template("sobre-nosotros.html")

@app.route("/soporte")
def soporte():
    return render_template("soporte.html")

# Rutas del menú de usuario
@app.route("/perfil")
def perfil():
    return render_template("perfil.html")

@app.route("/carrito")
def carrito():
    return render_template("carrito.html")

@app.route("/iniciar-sesion")
def iniciar_sesion():
    return render_template("iniciar-sesion.html")

# Rutas de productos individuales
@app.route("/producto/god-of-war")
def god_of_war():
    return render_template("prd-god.html")

@app.route("/producto/celeste")
def celeste():
    return render_template("prd-celeste.html")

@app.route("/producto/days-gone")
def days_gone():
    return render_template("prd-daysgone.html")

@app.route("/producto/dark-souls")
def dark_souls():
    return render_template("prd-darksouls.html")

@app.route("/producto/resident-evil-4")
def resident_evil_4():
    return render_template("prd-residentevil4.html")

@app.route("/producto/resident-evil-2")
def resident_evil_2():
    return render_template("prd-residentevil2.html")

@app.route("/categoria/accion")
def categoria_accion():
    return render_template("Accion.html")

@app.route("/categoria/aventura")
def categoria_aventura():
    return render_template("Aventura.html")

@app.route("/categoria/retro")
def categoria_retro():
    return render_template("Retro.html")

@app.route("/categoria/terror")
def categoria_terror():
    return render_template("Terror.html")

@app.route("/categoria/rol")
def categoria_rol():
    return render_template("Rol.html")

@app.route("/categoria/sandbox")
def categoria_sandbox():
    return render_template("Sandbox.html")

@app.route("/contactanos")
def contactanos():
    return render_template("contactanos.html")

@app.route("/historial-compras")
def historial_compras():
    return render_template("historial-compras.html")

@app.route("/lista-deseos")
def lista_deseos():
    return render_template("lista-deseos.html")

@app.route("/ruleta-game")
def ruleta_game():
    return render_template("ruleta-game.html")


@app.route("/registrar-usuario", methods=["GET","POST"])
def registrar_usuario():
    if request.method == "POST":
        usuario = request.form.get("username-user")
        nombre = request.form.get("name")
        password = request.form.get("password")
        email = request.form.get("email")
        telefono = request.form.get("phone")
        country = request.form.get("country")
        birth_date = request.form["birth_date"]
        gender = request.form["gender"]
        rolid_rol = 1  # Si hay un valor fijo para el rol, ajusta esto según sea necesario
        foto_perfil = "static/imagenes/MenuPrincipalyPerfil/perfil.jpg"  # O usa un valor predeterminado
        foto_portada = "static/imagenes/MenuPrincipalyPerfil/fondoPerfilAuto.jpg"  # O usa un valor predeterminado
        insertar_usuario(usuario,nombre,email,gender,password,telefono,country,birth_date,rolid_rol,foto_perfil,foto_portada)
        juegos= obtener_juegos()
        return render_template("tienda.html",juegos=juegos)
    else:
        return render_template("registrar-usuario.html")

@app.route("/perdida-contrasena")
def perdida_contrasena():
    return render_template("perdida-contrasena.html")

@app.route("/confirmar-compra")
def confirmar_compra():
    if "user_id" not in iniciar_sesion:
        return render_template("iniciar_sesion")
    return render_template("confirmarCompra.html")

@app.route('/producto/god-of-war-artbook')
def god_of_war_artbook():
    return render_template('prd-godA.html')

@app.route('/producto/god-of-war-deluxe')
def god_of_war_deluxe():
    return render_template('prd-godD.html')

@app.route('/producto/resident-evil-2-deluxe')
def resident_evil_2_deluxe():
    return render_template('prd-residentevil2D.html')

@app.route('/producto/resident-evil-4-gold')
def resident_evil_4_gold():
    return render_template('prd-residentevil4G.html')


# LO QUE ESTÁ HACIENDO SMAILLIPENE

@app.route('/agregar_juego', methods=['GET', 'POST'])
def ruta_agregar():
    if request.method == 'POST':
        resultado = agregar_juego(request)
        return resultado  # o redirect('/')
    return render_template('agregar_juego.html')



@app.route('/producto/<int:id_juego>')
def detalle_juego(id_juego):
    juego = obtener_juego_por_id(id_juego)
    similares = obtener_similares(juego[0])  # <-- función nueva
    return render_template('producto.html', juego=juego, similares=similares)


    





if __name__ == "__main__":
    app.run(debug=True)