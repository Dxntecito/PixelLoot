// const juegos = [
//     {
//         id:1,
//         nombre: "God of War",
//         sub: "god",
//         genero: ["Accion","Aventura"],
//         precio: 159.30,
//     },
//     {
//         id:2,
//         nombre: "Dark Souls",
//         sub: "darksouls",
//         genero: ["Rol","Aventura"],
//         precio: 115.10,
//     },
//     {
//         id:3,
//         nombre: "Days Gone",
//         sub: "daysgone",
//         genero: ["Sandbox","Aventura"],
//         precio: 159.20,
//     },
//     {
//         id:4,
//         nombre: "Resident Evil 4",
//         sub: "residentevil4",
//         genero: ["Terror","Accion"],
//         precio: 159.50,
//     },

//     {
//         id:5,
//         nombre:"Resident Evil 2",
//         sub: "residentevil2",
//         genero: ["Terror","Accion"],
//         precio: 149.60,
//     },
//     {
//         id:6,
//         nombre: "Celeste",
//         sub: "celeste",
//         genero: "retro",
//         precio: 43.10
//     },
//     {
//         id:12,
//         nombre: "God of War: Delux edition",
//         sub: "godD",
//         genero: ["Accion","Aventura"],
//         precio: 239.30,
//     },
//     {
//         id:12,
//         nombre: "God of War: Digital Artbook",
//         sub: "godA",
//         genero: ["Accion","Aventura"],
//         precio: 30.20,
//     },
//     {
//         id:13,
//         nombre:"Resident Evil 2: Delux edition",
//         sub: "residentevil2D",
//         genero: ["Terror","Accion"],
//         precio: 186.00,
//     },
//     {
//         id:14,
//         nombre: "Resident Evil 4: Gold edition",
//         sub: "residentevil4G",
//         genero: ["Terror","Accion"],
//         precio: 190.90,
//     },
//     {
//         id:7,
//         nombre: "Tekken 8",
//         genero: "Accion",
//         precio: 202.50,
//     },
//     {
//         id:8,
//         nombre: "Sekiro",
//         genero: "Rol",
//         precio: 217.50,
//     },
//     {
//         id:15,
//         nombre: "Tekken 8: Ultimate Edition",
//         genero: "Accion",
//         precio: 317.50,
//     },
//     {
//         id:11,
//         nombre: "Sekiro: GOTY Edition",
//         genero: "Rol",
//         precio: 280.70,
//     },
//     {
//         id:9,
//         nombre: "Terraria",
//         genero: "Retro",
//         precio: 23.90,
//     },
//     {
//         id:10,
//         nombre: "Proyect Zomboid",
//         genero: "SandBox",
//         precio: 42.99,
//     }

// ]